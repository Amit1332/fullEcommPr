const arrayD = [{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},
{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},{
    name: "TDX Sinkers",
    price: "₹ 675.00",
    type:'3',
    pic:"https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    npeoples: "121",
    star: 4
},
]
module.exports = arrayD;