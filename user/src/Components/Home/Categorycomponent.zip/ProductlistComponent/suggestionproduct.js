const arrayF = ["Gadgets","Fashion","Toys", "Educations", "Beauty", "Travel", "Fitness", "Furniture", "Sneakers"]
module.exports = arrayF; 