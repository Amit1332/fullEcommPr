import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import ReactStars from 'react-stars'
export default function Productlisthome({heading, data}) {
    const ratingChanged = (newRating) => {
        console.log(newRating)
      }
      const element = document.querySelector(".productlist")
      const [i,seti] = useState(0);
     const clickprevious = ()=>{
      if(i>=0){
        element.scroll({
          left: `${i}`,
          behavior: 'smooth'
        });
        seti(i-250);
        console.log(i);
      }
     }
     const clicknext = ()=>{
      if(i>=0 && i<=1002 ){
        seti(i+250);
        element.scroll({
          left: `${i}`,
          behavior: 'smooth'
        });
        console.log(i);
      }
     }
  return (
    

      

    <div className='Productlist'>
        <div className="navCategorycomponent">
        <h1>{heading}</h1>
       <Link>View All</Link>
       </div>
       <div className="slider23">
      <i class="las la-angle-left" onClick={clickprevious}></i>
      <i class="las la-angle-right" onClick={clicknext}></i>
      </div>
       <div className="productlist" >
      
        {data && data.map((ele)=>{
       return (
       <div className="product">
        <div className="productimg">
       <i class="lar la-heart"></i>
       <img src={ele.pic} alt="" />
        </div>
       <h4>{ele.name}</h4>
       <h3>{ele.price}</h3>
       <p>{ele.type} types of shoos available</p>
       <h5>
       <ReactStars count={5} value = {ele.star} onChange={ratingChanged} size={24} color2={'#ffd700'} />
        ({ele.npeoples})
       </h5>
        </div>
       )
    })}
    </div>
</div> 
  )
}
