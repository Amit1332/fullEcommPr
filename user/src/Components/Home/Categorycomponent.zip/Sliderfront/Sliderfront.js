import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import $ from 'jquery';
export default function Sliderfront() {
    useEffect(()=>{
        $(function(){
            var $width="100%"
        
        
            $("#menuBtn").on('click',function(){
                if(!$("#menuBtn").hasClass("open")){                     /*.hasClass（）检测一个元素有没有类 */
                    $("#menu").css({'display':'block','z-index':"10"});
                    $("#menuBtn").addClass("open");
                }
                else{
                    $("#menuBtn").removeClass("open");
                    $("#menu").css({'display':'none'});
                }
            });
        
            function play(preIndex,currentIndex){
                $('.slider-pics').eq(preIndex).fadeOut(500)
                .parent().children().eq(currentIndex).fadeIn(1000);
                $('.slider-item').removeClass('slider-item-selected');
                $('.slider-item').eq(currentIndex).addClass('slider-item-selected');
            }
        
            var currentIndex=0;
            var length = $(".slider-pics").length;
            function pre(){
                var preIndex = currentIndex;
                currentIndex = (--currentIndex + length) % length;
                play(preIndex,currentIndex);
            }
        
            function next(){
                var preIndex = currentIndex;
                currentIndex = ++currentIndex % length;
                play(preIndex,currentIndex);
            }
        
            var interval, hasStarted = false;
        
            function start(){
                if(!hasStarted){
                    hasStarted = true;
                    interval = setInterval(next,3000);
                }
            }
        
            function stop(){
                clearInterval(interval);
                hasStarted = false;
            }
        
            start();
            
            $('.slider-pics:not(:first)').hide();
            $('.slider-item:first').addClass('slider-item-selected');
            $('.slider-button').hide();
            $('.slider-pics, .slider-pre, .slider-next').hover(function(){
                stop();
                $(".slider-button").show();
            },function(){
                $('.slider-button').hide();
                start();
            });
        
        
            $('.slider-pre').on('click',function(){
                pre();
            });
            $('.slider-next').on('click',function(){
                next();
            });
        })
    })
  return (
    <div className='pslider'>
           
    <div className="slider">
        <ul className="main">
            <li className="slider-pics"><Link to={`#`}><img src=" https://static1.bcjiaoyu.com/e1126b376ca93e686e4fe983512293a6_f.jpg-5472x3078"/></Link></li>
            <li className="slider-pics"><Link to={`#`}><img src="https://static1.bcjiaoyu.com/45d285cc11b403cf4a369bd359864a37_l.jpg-3992x2242"/></Link></li>
            <li className="slider-pics"><Link to={`#`}><img src="https://static1.bcjiaoyu.com/71de73d33d4fc99aeb6d74d383cc7167_t.jpg-5464x3070"/></Link></li>
            <li className="slider-pics"><Link to={`#`}><img src=" https://static1.bcjiaoyu.com/2cb6c4273261bb3a36c553ed7a402e82_t.jpg-5464x3070"/></Link></li>
        </ul>
       
        <div className="slider-circle">
            <ul className="slider-nav">
                <li className="slider-item"></li>
                <li className="slider-item"></li>
                <li className="slider-item"></li>
                <li className="slider-item"></li>
            </ul>
        </div>
        <div className="slider-button">
            <Link to={`#`} className="slider-pre">  {`<`} </Link>
            <Link to={`#`} className="slider-next"> {`>`} </Link>
        </div>
    </div>

  
    </div>
  )
}
