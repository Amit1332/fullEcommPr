import React from 'react'

export default function Getstart() {
  return (
    <div className='GetStart'>
        <div className="textgetstart">
            <h1>Ready to get started?</h1>
            <p>Download the Flippy 7 app to find Cloths, Shoes, Toys and Watch's to buy, save and share your favourite products and get real-time alerts.</p>
        </div>
    </div>
  )
}
