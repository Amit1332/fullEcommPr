import React from 'react'
export default function Servicecomponent2() {
  return (
    <div  id='ser2'>
        <h1>Get in Touch</h1>
        <div className="Services">
            <p><i class="las la-phone"></i>0755 4857712</p>
            <p><i class="las la-envelope"></i>help@flippyseven.com</p>
            <p><i class="las la-map-marker-alt"></i><span> 3755 Commercial St SE Salem, Corner with Sunny Boulevard, 3755 Commercial OR 97302</span></p>
        </div>
    </div>
  )
}
